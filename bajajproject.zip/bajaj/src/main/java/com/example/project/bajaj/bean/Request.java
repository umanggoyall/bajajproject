package com.example.project.bajaj.bean;

import java.util.List;

public class Request {

	List<String> data;

	public List<String> getData() {
		return data;
	}

	public void setData(List<String> data) {
		this.data = data;
	}
}
